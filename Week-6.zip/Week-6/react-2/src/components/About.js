import React from "react";
function About()
{
    return <h1>Welcome to the About page of student management portal</h1>
}

export default About;